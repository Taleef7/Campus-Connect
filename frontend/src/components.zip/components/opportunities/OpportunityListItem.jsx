import React from 'react';
import {
  Paper, Box, Typography, Chip, IconButton, Button, Divider
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import GroupIcon from '@mui/icons-material/Group';

const OpportunityListItem = ({
  opportunity,
  onEdit,
  onDelete,
  onViewInterested,
  viewMode
}) => {
  const isProfessorView = viewMode === 'professor';

  const formatDate = (timestamp) => {
    if (!timestamp) return '—';
    const date = new Date(timestamp.seconds ? timestamp.seconds * 1000 : timestamp);
    return date.toLocaleDateString();
  };

  return (
    <Paper elevation={2} sx={{ p: 2, mb: 2, borderRadius: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap' }}>
        {/* Opportunity Info */}
        <Box sx={{ mb: 1 }}>
          <Typography variant="h6">{opportunity.title}</Typography>
          <Chip label={opportunity.type || 'General'} size="small" sx={{ mr: 1, mb: 1 }} />
          {opportunity.allowInterest && (
            <Chip label="Interest Enabled" size="small" color="success" variant="outlined" sx={{ mb: 1 }} />
          )}
        </Box>

        {/* Action Buttons (Visible for professors only) */}
        {isProfessorView && (
          <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center' }}>
            {opportunity.allowInterest && (
              <Button
                size="small"
                startIcon={<GroupIcon />}
                onClick={() => onViewInterested(opportunity.id)}
                variant="outlined"
              >
                View Interested
              </Button>
            )}
            {onEdit && (
              <IconButton size="small" onClick={() => onEdit(opportunity)}>
                <EditIcon fontSize="small" />
              </IconButton>
            )}
            {onDelete && (
              <IconButton size="small" onClick={() => onDelete(opportunity.id)}>
                <DeleteIcon fontSize="small" color="error" />
              </IconButton>
            )}
          </Box>
        )}
      </Box>

      <Divider sx={{ my: 1 }} />

      <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap', mb: 1 }}>
        {opportunity.description}
      </Typography>

      <Typography variant="caption" color="text.secondary">
        Posted on: {formatDate(opportunity.createdAt)}
      </Typography>
    </Paper>
  );
};

export default OpportunityListItem;
